export default color = {
  primary: "#fc5c65",
  secondary: "#4ECDC4",
  white: "#fff",
  grey: "#f8f4f4",
  gray: "#939397",
};
